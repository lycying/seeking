# coding:utf-8
#
# Copyright (c) 2010, guo.li <lycying@gmail.com>
# Site < http://code.google.com/p/seeking/ >
# All rights reserved.
# vim: set ft=python sw=2 ts=2 et:
#
import os
import time
import sys
import sqlite3 as sqlite
import re
from urllib2 import urlopen 
import thread
import traceback

from PyQt4.QtGui import QWidget
from PyQt4.QtGui import QLabel
from PyQt4.QtGui import QLineEdit
from PyQt4.QtGui import QMessageBox
from PyQt4.QtGui import QIcon
from PyQt4.QtGui import QFileDialog

from PyQt4.QtGui import QHBoxLayout

from PyQt4.QtCore import QVariant
from PyQt4.QtCore import QObject
from PyQt4.QtCore import SIGNAL
from PyQt4.QtCore import pyqtSignature
from PyQt4.QtCore import Qt



from sklib.config import Prefs, getPath, getPrccisePath
from sklib.ui.support import PluginBase
from sklib.ui.uimain import Seeking
from sklib.security import sk_encode,sk_decode

from plugins.yeahdoc.Ui_FetchView import Ui_FetchView

            
    
class YeahdocDatasSupply(object):
    """
    The yeahdoc datas supply . 
    read , update or delete datas use sqlite3
    """
    def __init__(self):
        self.STOREDIR = ""
        
        userDefinedDir = YeahdocExtConfig().getStoreDir()
        
        if userDefinedDir == None or userDefinedDir ==  "":
            QMessageBox.information(Seeking().new(), "Welcome", "This is the first time you run yeahdoc-plguin: please select your store dir . \n if you do not know what to do , Select cancel ")
            temp = getPath("dataDir", "yeahdoc/default.db")
            if temp is None:
                
                if sys.platform.startswith("win"):
                    self.STOREDIR = getPrccisePath("dataDir", "yeahdoc/","extdir")
                else:
                    self.STOREDIR = getPrccisePath("dataDir", "yeahdoc/","userdir")
                    
                self.STOREDIR = self.STOREDIR.replace("\\", "/")
                
            else:
                self.STOREDIR = temp.replace("default.db","")
                
            directory = QFileDialog.getExistingDirectory(Seeking().new(),"Store Dir",self.STOREDIR, QFileDialog.ShowDirsOnly)
            if directory:
                self.STOREDIR = directory
            else:
                QMessageBox.information(Seeking().new(), "Welcome", "make default dir %s" % self.STOREDIR)

            YeahdocExtConfig().setStoreDir(self.STOREDIR)
            
        else:
            self.STOREDIR = userDefinedDir
        
        self.DATAFILE = "%s/default.db" % self.STOREDIR
        if not  os.path.exists(self.STOREDIR):
            os.makedirs(self.STOREDIR)
        if not  os.path.exists(self.DATAFILE):
            self.__install()
            
                
        self.MAXLINE = int(YeahdocExtConfig().getNumberPerPage())
    def __install(self):
        """
        init db file
        """
        self.__dbBegin()
        self.stmt.execute("CREATE TABLE yeahdoc (star NUMERIC, lock NUMERIC, categoryid NUMERIC, desc TEXT, createdate varchar(20), img varchar(100), tags varchar(500), id INTEGER PRIMARY KEY, title varchar(200), content TEXT);")
        self.stmt.execute("CREATE TABLE category (img varchar(100), id INTEGER PRIMARY KEY, title varchar(100), desc TEXT, yeahdocnum NUMERIC,lock NUMERIC, createdate varchar(20));")
        self.stmt.execute("CREATE TABLE yeahdocextends (id INTEGER PRIMARY KEY, yeahdocid NUMERIC, createdate varchar(20), content TEXT);")
        self.stmt.execute("INSERT INTO category VALUES('default.png',1,'Default','<html><head></head><body>Default</body></html>',0,0,2010101010101010);")
        self.__dbEnd()

    def __dbBegin(self):
        """
        init connection and statement
        """
        self.conn = sqlite.connect(self.DATAFILE)
        self.stmt = self.conn.cursor()

    def __dbEnd(self):
        """
        close the db.
        """
        self.conn.commit()
        self.stmt.close()
        self.conn.close()

    def bb_list(self,categoryid=None):
        """
        Read the Data/item files . the return structs is :
        """
        yeahdoc_list = []
        sql = "select id,img,createdate,desc,title,star,lock from yeahdoc order by id desc limit %d offset 0" % self.MAXLINE
        if categoryid!=None:
            sql =  "select id,img,createdate,desc,title,star,lock from yeahdoc where categoryid=%s order by id desc  " % categoryid
        
        self.__dbBegin()
        
        self.stmt.execute(sql)
        list = self.stmt.fetchall()
        for item in list:
            yeahdoc_list.append({
                    "title":item[4], \
                    "img":item[1], \
                    "createdate":item[2], \
                    "id":str(item[0]),\
                    "star":item[5],\
                    "lock":item[6]
                    })
        
        self.__dbEnd()
    
        return yeahdoc_list
    def bb_lock(self,id,password):
        request = self.bb_read1(id)["content"]
        result = sk_encode(request, password)
        sql = "update  yeahdoc set lock=1,content=? where id=%s" % id
        self.__dbBegin()
        self.stmt.execute(sql,(result,))
        self.__dbEnd()
    def bb_unlock(self,id,password):
        request = self.bb_read1(id)["content"]
        result = sk_decode(request, password)
        sql = "update  yeahdoc set lock=0,content=? where id=%s" % id
        self.__dbBegin()
        self.stmt.execute(sql,(result,))
        self.__dbEnd()
    def bb_read1_simple(self,id):
        """
        avoid large datas, just simple infomation
        """
        
        sql = "select id,img,createdate,title,categoryid,desc,lock from yeahdoc where id=%s"%id 
        self.__dbBegin()
        
        self.stmt.execute(sql)

        rs      = self.stmt.fetchone()
        title   = rs[3]
        icon    = rs[1]
        categoryid = rs[4]
        desc    = rs[5]
        lock    = rs[6]
        
        self.__dbEnd()
        
        title = "%s.." % title[0:8] if len(title)>8 else title
        return {"title":title,"img":icon,"categoryid":categoryid,"desc":desc,"lock":lock}
    
    def bb_read1(self,id):
        """
        get the yeahdoc infomation and display it 
        """
        sql = "select id,img,createdate,title,desc,content,categoryid,lock from yeahdoc where id= %s" %id
        self.__dbBegin()
        
        self.stmt.execute(sql)
        rs      = self.stmt.fetchone()
        title   = rs[3]
        icon    = rs[1]
        content = rs[5]
        desc    = rs[4]
        categoryid = rs[6]
        createdate=rs[2]
        lock    = rs[7]
        
        self.__dbEnd()
        
        return {"title":title,"img":icon,"content":content,"desc":desc,"createdate":createdate,"categoryid":categoryid,"lock":lock}
    
    def bb_save(self,categoryid,title,tags,img,content,password,id):
        """
        save or update the yeahdoc
        """
        lock = 0 if password=="" else 1
        createdate = time.strftime("%Y-%m-%d %H:%M:%S",time.localtime())
        insert_sql = "insert into yeahdoc (categoryid,title,img,tags,createdate,star,content,desc,lock) values(%s,'%s','%s','%s','%s',0,?,?,%d)" % (categoryid,title,img,tags,createdate,lock)
        update_sql = "update  yeahdoc set categoryid=%s,title='%s',img='%s',tags='%s',content=?,desc=?,lock=%s where id=%s" % (categoryid,title,img,tags,lock,id)
        self.__dbBegin()
        
        desc  = "%s.." % content[0:500] if len(content)>500 else content
        #encode the content .
        if not password=="":
            content = sk_encode(content, password)
            
        if id == "~":
            #next seq 
            self.stmt.execute("select max(id) as n from yeahdoc ")
            try:
                id = self.stmt.fetchone()[0]+1
            except:
                id = 1
            self.stmt.execute(insert_sql,(content,desc,))
        else:
            self.stmt.execute(update_sql,(content,desc,))
            
        self.__dbEnd()
        
        return str(id)

    def bb_delete(self,id):
        """
        delete yeahdoc item from db
        """
        sql = "delete from yeahdoc where id=%s" % id
        self.__dbBegin()
        
        self.stmt.execute(sql)
        
        self.__dbEnd()
        return True

    
    def bb_update_title(self,value,id):
        """
        this may used when rename a yeahdoc
        """
        sql = "update  yeahdoc set title='%s'where id=%s" %(value,id)
        
        self.__dbBegin()
        
        self.stmt.execute(sql)
        
        self.__dbEnd()
        return True
    
    def bb_update_class(self,value,id):
        """
        change the yeahdoc class
        """
        
        sql = "update  yeahdoc set categoryid=%s where id=%s" %(value,id)
        
        self.__dbBegin()
        
        self.stmt.execute(sql)
        
        self.__dbEnd()
        return True
    
    def bb_toggle_star(self,id):
        """
        toggle star flag
        """
        selectsql = "select star from yeahdoc where id=%s"%id
        sql = "update  yeahdoc set star=? where id=%s"%id
        
        self.__dbBegin()
        
        self.stmt.execute(selectsql)
        fx = self.stmt.fetchone()[0]
        if 0==fx:
            self.stmt.execute(sql,(1,))
        else:
            self.stmt.execute(sql,(0,))
            
        self.__dbEnd()
        return fx
    
    def bc_list(self):
        """
        read class list datas
        """
        yeahdoc_class_list = []
        sql = "select id,img,createdate,desc,title,lock from category order by id desc"
        self.__dbBegin()
        
        self.stmt.execute(sql)
        list = self.stmt.fetchall()
        for item in list:
            yeahdoc_class_list.append({"id":item[0],"title":item[4], "img":item[1], "createdate":item[2],"lock":item[5]})
            
        self.__dbEnd()
    
        return yeahdoc_class_list

    def bc_save(self,title,img,desc,id):
        """
        save yeahdoc class item
        """
        createdate = time.strftime("%Y-%m-%d %H:%M:%S",time.localtime())
        insert_sql = "insert into category (title,img,createdate,desc) values('%s','%s','%s',?)" %(title,img,createdate)
        update_sql = "update  category set title='%s',img='%s',desc=? where id=%s" %(title,img,id)
        
        self.__dbBegin()
        
        if id == "~":
            self.stmt.execute("select max(id) as n from category ")
            try:
                id = self.stmt.fetchone()[0]+1
            except:
                id = 1
            self.stmt.execute(insert_sql,(desc,))
        else:
            self.stmt.execute(update_sql,(desc,))
            
        self.__dbEnd()
        return str(id)
    
    def bc_read1(self,id):
        """ read yeahdoc class item data """
        sql = "select id,img,createdate,title,desc,lock from category where id=%s" % id
        
        self.__dbBegin()
        
        self.stmt.execute(sql)
        rs      = self.stmt.fetchone()
        id      = rs[0]
        title   = rs[3]
        icon    = rs[1]
        desc    = rs[4]
        createdate=rs[2]
        lock    = rs[5]
        
        self.__dbEnd()
        
        return {"id":id,"title":title,"img":icon,"desc":desc,"createdate":createdate,"lock":lock}
    
    def bc_update_title(self,value,id):
        """
        this may used when rename a yeahdoc
        """
        sql = "update  category set title='%s'where id=%s" %(value,id)
        
        self.__dbBegin()
        
        self.stmt.execute(sql)
        
        self.__dbEnd()
        return True
    def bc_delete(self,id):
        """
        delete yeahdoc class item
        """
        sql = "delete from category where id=%s"%id
        sql2 = "delete from yeahdoc where categoryid=%s"%id
        
        self.__dbBegin()
        self.stmt.execute(sql)
        self.stmt.execute(sql2);
        
        self.__dbEnd()
        return True

    def bc_merge(self,id,id2id):
        """
        merge the id into id2id
        """
        sql = "update yeahdoc set categoryid=%s where categoryid=%s" % (str(id2id),str(id))
        self.__dbBegin()
        self.stmt.execute(sql)
        self.__dbEnd()

    def bc_clear(self,id):
        """
        clear the datas of this category
        """
        sql = "delete from yeahdoc where categoryid=%s"%id
        self.__dbBegin()
        self.stmt.execute(sql)
        self.__dbEnd()
    
    
class YeahdocExtConfig(object):
    """
    yeahdoc config
    """
    def __init__(self):
        self.settings = Prefs.new().getSettings()
    
    
    def getNumberPerPage(self):
        """
        number per page show
        """
        return self.settings.value("UI/Plugin/yeahdoc/numberperpage",
                QVariant(100)).toString()
    
    def setNumberPerPage(self,num):
        """
        number per page show
        """
        value = QVariant(50)
        if isinstance(num,int) or num.isdigit():
            value = QVariant(num)
        self.settings.setValue("UI/Plugin/yeahdoc/numberperpage", value)
        
    def getStoreDir(self):
        """
        Module function to retrieve the language for the user interface.
        """
        storedir = self.settings.value("UI/Plugin/yeahdoc/storedir",QVariant("")).toString()
        
        return None if storedir is "None" or storedir is "" or storedir is None else storedir
    
    def setStoreDir(self,storedir):
        """
        Module function to store the language for the user interface.
        """
        self.settings.setValue("UI/Plugin/yeahdoc/storedir", QVariant("" if storedir is None else storedir))


class FetchView(QWidget,PluginBase,Ui_FetchView):
    """
    This is an generic user interface of 'Import and export'. 
    Used to provide  feedback on progress and the customize configuration
    """
    def __init__(self,singleflag="",ext=None):
        QWidget.__init__(self)
        PluginBase.__init__(self)
        
        self.setKeepme("[yeahdoc]FW-%s"%singleflag)
        self.ext = ext
        
        self.setupUi(self)
        
    def __evt_toggle_view(self):
        """
        toggle the yeahdoc view
        """
        if self.extoption.isVisible():
            self.extoption.setVisible(False)
            self.toggleBtn.setArrowType(Qt.DownArrow)
        else:
            self.extoption.setVisible(True)    
            self.toggleBtn.setArrowType(Qt.UpArrow)
    #Override#
    def invoke(self):
        
        if self.ext is not None:
            self.extoption.setLayout(self.ext)
            
        QObject.connect(self.toggleBtn,\
                        SIGNAL("clicked ()"),\
                        self.__evt_toggle_view)
        QObject.connect(self,SIGNAL("feedback"),self.feedback)
        
    @pyqtSignature("")
    def feedback(self,percent,number,text):
        """
        provide  feedback on progress
        """
        self.progressBar.setValue(percent)
        self.leftlcd.display(number)
        self.textBrowser.append(text)
        


class ImExportTools(object):
    def importQZone(self):
        ImportQZoneTool()


class ImportQZoneTool():
    """
    For :qzone.qq.com
    """
    def widgetOption(self):
        
        layout = QHBoxLayout()
        layout.addWidget(QLabel("<img src='%s'/>input your qq number:" % getPath("iconDir","yeahdoc/ext/qq.png")))
        layout.addWidget(self.qqInput)
        return layout
    
    def __init__(self):
        
        self.qqInput = QLineEdit()
        
        
        self.fetchView = FetchView("QZone",self.widgetOption())
        self.fetchView.execute("QZone...",QIcon(getPath("iconDir","yeahdoc/ext/qq.png")))
        
        self.fetchView.emit(SIGNAL("feedback"),0, 0, "I'm ready ! Wait operation...:) input your qq number and click start")
        
        QObject.connect(self.fetchView.startBtn, SIGNAL("clicked ()"),lambda :self._evt_start())
        #self.fetchByPage(0)
    def _evt_start(self):
        self.fetchView.startBtn.setDisabled(True)
        #self.QQ = "632603972"
        self.fetchView.emit(SIGNAL("feedback"),0, 0, "Preparing data...")
        self.QQ = self.qqInput.text()
        if self.QQ == "":
            self.fetchView.emit(SIGNAL("feedback"),0, 0, "Please supply a QQ number")
            self.fetchView.startBtn.setDisabled(False)
            return#stop
        
        thread.start_new_thread(self.reallyrun,())
        
    def reallyrun(self):
        self.fetchView.emit(SIGNAL("feedback"),0, 0, "Obtain QQ number:%s"%self.QQ)
        self.categoryid = YeahdocDatasSupply().bc_save("QZone:%s" % self.QQ ,"default.png","QZone datas from %s" %self.QQ,"~")
        self.fetchView.emit(SIGNAL("feedback"),0, 0, "Create new class with id :%s"%self.categoryid)
        self.fetchView.emit(SIGNAL("feedback"),0, 0, "wait...")
        self.total = 1
        try:
            self.fetchByPage(0)
        except Exception , ex:
            self.fetchView.emit(SIGNAL("feedback"),0, 0, "<span style='color:red'>An error occured :</span>%s"%str(ex) )
            self.fetchView.emit(SIGNAL("feedback"),0, 0, "<span style='color:red'>Exceptions :</span><pre>%s</pre>" % str(traceback.format_exc()) )
            self.fetchView.startBtn.setDisabled(False)
            
    def fetchByPage(self,pos):
            COUNT = pos
            fetchUrl = "http://b.qzone.qq.com/cgi-bin/blognew/simpleqzone_blog_title?hostuin=%(qq)s&r=0&idm=qzs.qq.com&bdm=b.qzone.qq.com&mdm=m.qzone.qq.com&pos=%(pos)d"
            
            ITEM_URL_RE = re.compile("<span class=\"list_tit\">.<a href=\"(.*)\">(.*)<\/a>")
            NEXT_PAGE_FLAG_RE = re.compile(u"<a(.*)>下一页<\/a>") 
            PAGE_STOP_WOED = "disabled"
            TOTOAL_RE = re.compile(u"共<span class=\"em\">(.*)</span>篇日志")
            

            res = urlopen(fetchUrl % {'qq':self.QQ,'pos':pos}) # This error may caused by : no this qq number or Qzone's protocal changed
            html = res.read().decode("gbk")
            res.close()
            
            if  self.total == 1:
                self.total = int(TOTOAL_RE.findall(html)[0])   #This error may caused by : no this qq number ,if no datas or no permissions , this error came
            
            for item in ITEM_URL_RE.findall(html):             #This error may caused by : no this qq number ,if no datas or no permissions , this error came
                itemUrl = item[0]
                itemName = item[1]
        
                self.fetchPage(itemName,itemUrl,COUNT)
                
                COUNT = COUNT+1 
        
            if NEXT_PAGE_FLAG_RE.findall(html)[0].__contains__(PAGE_STOP_WOED):
                self.fetchView.emit(SIGNAL("feedback"),100, 0, "done : fetch %d pages " % COUNT)
                self.fetchView.startBtn.setText("Done ")
            else:
    
                self.fetchByPage(COUNT+1)
        
    def fetchPage(self,title,url,pos):
        
            
            C_BEGIN = "<!--S日志内容-->".decode("utf-8")
            C_END = "<!--E日志内容-->".decode("utf-8")
                
            try:
                res = urlopen(url)
                html = res.read().decode("gbk")
                res.close()
            
                content = html[html.find(C_BEGIN):html.find(C_END)]
                newcontent=\
                    content.replace('src=\'/qzone/images/loading2.gif\'','').replace('src=\"/qzone/images/loading2.gif\"','').replace('thumb','src')
                    
                YeahdocDatasSupply().bb_save(self.categoryid, title, "", "default.png", newcontent, "","~")
                
                self.fetchView.emit(SIGNAL("feedback"),pos*100/self.total, self.total-pos, "Process: %s,At: %s" % (title,url))
            except:
                pass
            
