# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'FetchView.ui'
#
# Created: Thu Dec 09 22:23:00 2010
#      by: PyQt4 UI code generator 4.7.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_FetchView(object):
    def setupUi(self, FetchView):
        FetchView.setObjectName("FetchView")
        FetchView.resize(607, 500)
        FetchView.setAutoFillBackground(True)
        self.horizontalLayout_3 = QtGui.QHBoxLayout(FetchView)
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.extoption = QtGui.QWidget(FetchView)
        self.extoption.setAutoFillBackground(True)
        self.extoption.setObjectName("extoption")
        self.verticalLayout.addWidget(self.extoption)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem)
        self.startBtn = QtGui.QPushButton(FetchView)
        self.startBtn.setObjectName("startBtn")
        self.horizontalLayout_2.addWidget(self.startBtn)
        self.toggleBtn = QtGui.QToolButton(FetchView)
        self.toggleBtn.setMaximumSize(QtCore.QSize(12, 12))
        self.toggleBtn.setIconSize(QtCore.QSize(24, 10))
        self.toggleBtn.setArrowType(QtCore.Qt.UpArrow)
        self.toggleBtn.setObjectName("toggleBtn")
        self.horizontalLayout_2.addWidget(self.toggleBtn)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.textBrowser = QtGui.QTextBrowser(FetchView)
        self.textBrowser.setObjectName("textBrowser")
        self.verticalLayout.addWidget(self.textBrowser)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label = QtGui.QLabel(FetchView)
        self.label.setObjectName("label")
        self.horizontalLayout.addWidget(self.label)
        self.leftlcd = QtGui.QLCDNumber(FetchView)
        self.leftlcd.setAutoFillBackground(True)
        self.leftlcd.setMode(QtGui.QLCDNumber.Oct)
        self.leftlcd.setObjectName("leftlcd")
        self.horizontalLayout.addWidget(self.leftlcd)
        self.progressBar = QtGui.QProgressBar(FetchView)
        self.progressBar.setAutoFillBackground(True)
        self.progressBar.setProperty("value", 0)
        self.progressBar.setObjectName("progressBar")
        self.horizontalLayout.addWidget(self.progressBar)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.horizontalLayout_3.addLayout(self.verticalLayout)

        self.retranslateUi(FetchView)
        QtCore.QMetaObject.connectSlotsByName(FetchView)

    def retranslateUi(self, FetchView):
        FetchView.setWindowTitle(QtGui.QApplication.translate("FetchView", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.startBtn.setText(QtGui.QApplication.translate("FetchView", "Start", None, QtGui.QApplication.UnicodeUTF8))
        self.toggleBtn.setText(QtGui.QApplication.translate("FetchView", "...", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("FetchView", "Remaining:", None, QtGui.QApplication.UnicodeUTF8))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    FetchView = QtGui.QWidget()
    ui = Ui_FetchView()
    ui.setupUi(FetchView)
    FetchView.show()
    sys.exit(app.exec_())

