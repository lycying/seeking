# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'YeahdocEditor.ui'
#
# Created: Fri Jan 14 16:42:55 2011
#      by: PyQt4 UI code generator 4.8.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_YeahdocEditor(object):
    def setupUi(self, YeahdocEditor):
        YeahdocEditor.setObjectName(_fromUtf8("YeahdocEditor"))
        YeahdocEditor.resize(640, 446)
        YeahdocEditor.setAutoFillBackground(True)
        YeahdocEditor.setTabPosition(QtGui.QTabWidget.West)
        YeahdocEditor.setTabShape(QtGui.QTabWidget.Triangular)
        YeahdocEditor.setDocumentMode(True)
        self.tabview = QtGui.QWidget()
        self.tabview.setObjectName(_fromUtf8("tabview"))
        self.verticalLayout = QtGui.QVBoxLayout(self.tabview)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.titlelabel = QtGui.QLabel(self.tabview)
        self.titlelabel.setMaximumSize(QtCore.QSize(800, 30))
        self.titlelabel.setText(_fromUtf8(""))
        self.titlelabel.setObjectName(_fromUtf8("titlelabel"))
        self.verticalLayout.addWidget(self.titlelabel)
        YeahdocEditor.addTab(self.tabview, _fromUtf8(""))
        self.tabeditor = QtGui.QWidget()
        self.tabeditor.setAutoFillBackground(True)
        self.tabeditor.setObjectName(_fromUtf8("tabeditor"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.tabeditor)
        self.verticalLayout_2.setSpacing(5)
        self.verticalLayout_2.setContentsMargins(-1, -1, -1, 9)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.linelayout = QtGui.QHBoxLayout()
        self.linelayout.setSpacing(6)
        self.linelayout.setObjectName(_fromUtf8("linelayout"))
        self.label_2 = QtGui.QLabel(self.tabeditor)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.linelayout.addWidget(self.label_2)
        self.titleInput = QtGui.QLineEdit(self.tabeditor)
        self.titleInput.setMinimumSize(QtCore.QSize(0, 23))
        self.titleInput.setMaximumSize(QtCore.QSize(1000, 23))
        self.titleInput.setObjectName(_fromUtf8("titleInput"))
        self.linelayout.addWidget(self.titleInput)
        self.label = QtGui.QLabel(self.tabeditor)
        self.label.setObjectName(_fromUtf8("label"))
        self.linelayout.addWidget(self.label)
        self.classlist = QtGui.QComboBox(self.tabeditor)
        self.classlist.setObjectName(_fromUtf8("classlist"))
        self.linelayout.addWidget(self.classlist)
        self.taglabel = QtGui.QLabel(self.tabeditor)
        self.taglabel.setObjectName(_fromUtf8("taglabel"))
        self.linelayout.addWidget(self.taglabel)
        self.tagsInput = QtGui.QLineEdit(self.tabeditor)
        self.tagsInput.setMaximumSize(QtCore.QSize(200, 23))
        self.tagsInput.setObjectName(_fromUtf8("tagsInput"))
        self.linelayout.addWidget(self.tagsInput)
        self.saveBtn = QtGui.QPushButton(self.tabeditor)
        self.saveBtn.setObjectName(_fromUtf8("saveBtn"))
        self.linelayout.addWidget(self.saveBtn)
        self.passwordMore = QtGui.QPushButton(self.tabeditor)
        self.passwordMore.setFlat(True)
        self.passwordMore.setObjectName(_fromUtf8("passwordMore"))
        self.linelayout.addWidget(self.passwordMore)
        self.passwordWidget = QtGui.QWidget(self.tabeditor)
        self.passwordWidget.setEnabled(True)
        self.passwordWidget.setObjectName(_fromUtf8("passwordWidget"))
        self.horizontalLayout = QtGui.QHBoxLayout(self.passwordWidget)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setMargin(0)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.password1 = QtGui.QLineEdit(self.passwordWidget)
        self.password1.setEchoMode(QtGui.QLineEdit.Password)
        self.password1.setObjectName(_fromUtf8("password1"))
        self.horizontalLayout.addWidget(self.password1)
        self.relabel = QtGui.QLabel(self.passwordWidget)
        self.relabel.setObjectName(_fromUtf8("relabel"))
        self.horizontalLayout.addWidget(self.relabel)
        self.password2 = QtGui.QLineEdit(self.passwordWidget)
        self.password2.setEchoMode(QtGui.QLineEdit.Password)
        self.password2.setObjectName(_fromUtf8("password2"))
        self.horizontalLayout.addWidget(self.password2)
        self.linelayout.addWidget(self.passwordWidget)
        self.verticalLayout_2.addLayout(self.linelayout)
        YeahdocEditor.addTab(self.tabeditor, _fromUtf8(""))

        self.retranslateUi(YeahdocEditor)
        YeahdocEditor.setCurrentIndex(1)
        QtCore.QMetaObject.connectSlotsByName(YeahdocEditor)

    def retranslateUi(self, YeahdocEditor):
        YeahdocEditor.setWindowTitle(QtGui.QApplication.translate("YeahdocEditor", "TabWidget", None, QtGui.QApplication.UnicodeUTF8))
        YeahdocEditor.setTabText(YeahdocEditor.indexOf(self.tabview), QtGui.QApplication.translate("YeahdocEditor", "View", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("YeahdocEditor", "Title", None, QtGui.QApplication.UnicodeUTF8))
        self.titleInput.setToolTip(QtGui.QApplication.translate("YeahdocEditor", "<h1>Input something as title</h1>", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("YeahdocEditor", "Category", None, QtGui.QApplication.UnicodeUTF8))
        self.taglabel.setText(QtGui.QApplication.translate("YeahdocEditor", "Tags", None, QtGui.QApplication.UnicodeUTF8))
        self.saveBtn.setText(QtGui.QApplication.translate("YeahdocEditor", "Save", None, QtGui.QApplication.UnicodeUTF8))
        self.passwordMore.setText(QtGui.QApplication.translate("YeahdocEditor", "Encrypt", None, QtGui.QApplication.UnicodeUTF8))
        self.relabel.setText(QtGui.QApplication.translate("YeahdocEditor", "Re", None, QtGui.QApplication.UnicodeUTF8))
        YeahdocEditor.setTabText(YeahdocEditor.indexOf(self.tabeditor), QtGui.QApplication.translate("YeahdocEditor", "Edit", None, QtGui.QApplication.UnicodeUTF8))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    YeahdocEditor = QtGui.QTabWidget()
    ui = Ui_YeahdocEditor()
    ui.setupUi(YeahdocEditor)
    YeahdocEditor.show()
    sys.exit(app.exec_())

