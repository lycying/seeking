# coding:utf-8
#
# Copyright (c) 2010, guo.li <lycying@gmail.com>
# Site < http://code.google.com/p/seeking/ >
# All rights reserved.
# vim: set ft=python sw=2 ts=2 et:
#


import os

from PyQt4.QtGui import QIcon
from PyQt4.QtGui import QWidget
from PyQt4.QtGui import QAction
from PyQt4.QtGui import QTabWidget
from PyQt4.QtGui import QMenu
from PyQt4.QtGui import QListWidgetItem
from PyQt4.QtGui import QTreeWidgetItem
from PyQt4.QtGui import QHeaderView
from PyQt4.QtGui import QMessageBox
from PyQt4.QtGui import QToolBar
from PyQt4.QtGui import QDialogButtonBox
from PyQt4.QtGui import QPushButton
from PyQt4.QtGui import QToolButton
from PyQt4.QtGui import QDialog
from PyQt4.QtGui import QListView
from PyQt4.QtGui import QApplication
from PyQt4.QtGui import QDesktopWidget
from PyQt4.QtGui import QWidgetAction
from PyQt4.QtGui import QLabel
from PyQt4.QtGui import QHBoxLayout
from PyQt4.QtGui import QLineEdit
from PyQt4.QtGui import QSpacerItem
from PyQt4.QtGui import QSizePolicy
from PyQt4.QtGui import QInputDialog

from PyQt4.QtCore import Qt
from PyQt4.QtCore import QObject
from PyQt4.QtCore import QSize
from PyQt4.QtCore import SIGNAL
from PyQt4.QtCore import pyqtSignature

from sklib.ui.support import PluginBase 
from sklib.ui.wysiwyg import HtmlWYSIWYG, HtmlBrowser
from sklib.ui.uimain import Seeking

from plugins.yeahdoc.Ui_YeahdocEditor import Ui_YeahdocEditor
from plugins.yeahdoc.Ui_YeahdocList import Ui_YeahdocList
from plugins.yeahdoc.Ui_NewYeahdocCategory import Ui_NewYeahdocCategory
from plugins.yeahdoc.yeahdocsupport import ImExportTools, YeahdocDatasSupply

from sklib.config import getPath, Prefs
from sklib.security import sk_decode, sk_encode



#Info ===
name = "Yeahdoc Plugin"
author = "lycy < lycying@gmail.com >"
version = "0.1"
packageName = "__core__"
description = "Used to record you articals "
#Info ===

def install():
    """
    The function that init the plugin . just once .
    core package ignore
    """
    pass

def uninstall():
    """
    The method that remove the plugin .
    core package ignore
    """
    pass
def activate():
    """
    used to make use of the plugin
    """
    def __evt_new():
        """
        new yeahdoc evt 
        """
        yeahdoc = AdapterYeahdocItemViewerAndEditor(":new[Yeahdoc]")
        yeahdoc.setCurrentIndex(1)
        yeahdoc.setBufferon(True)
        yeahdoc.execute(":new[Yeahdoc]",QIcon(getPath('iconDir','yeahdoc/new.png')))
        
    def __evt_list():
        """
        show yeahdoc list
        """
        yeahdoclist = AdapterMainYeahdocListView()
        yeahdoclist.execute(QApplication.translate("YeahdocList", "Yeahdoc"),QIcon(getPath('iconDir','yeahdoc/list.png')))

    #setup the mainwindow UI 
    # New global action can be added to the list of global action
    sk = Seeking.new()
    
    sk.regAction("__yeahdoc_new",\
            QAction(QIcon(getPath('iconDir','yeahdoc/new.png')),\
            QApplication.translate("YeahdocEditor","New Yeahdoc"),sk,\
            triggered=__evt_new))
    sk.regAction("__yeahdoc_list",\
            QAction(QIcon(getPath('iconDir','yeahdoc/list.png')),\
            QApplication.translate("YeahdocList","Yeahdoc"),sk,\
            triggered=__evt_list))

    #set default shortcut
    sk.getAction("__yeahdoc_new").setShortcut(Prefs.new().getShortcut("__yeahdoc_new","Ctrl+N"))
    sk.getAction("__yeahdoc_list").setShortcut(Prefs.new().getShortcut("__yeahdoc_list","Ctrl+L"))

    #global toolbar
    toolbar = sk.addToolBar(QApplication.translate("YeahdocList","Yeahdoc"))
    toolbar.addAction(sk.getAction("__yeahdoc_new"))
    toolbar.addAction(sk.getAction("__yeahdoc_list"))

    #global menu
    sk.getMenu("file").addAction(sk.getAction("__yeahdoc_new"))
    sk.getMenu("file").addAction(sk.getAction("__yeahdoc_list"))
    sk.getMenu("file").addSeparator()
    
def deactivate():
    """
    make this plugin disabled
    """
    pass
    
def getActions():
    """
    get All actions that will be config its shortcut
    """ 
    return {QApplication.translate("YeahdocList","Yeahdoc"):AdapterMainYeahdocListView().getActions(),\
            QApplication.translate("YeahdocEditor","Yeahdoc"):AdapterYeahdocItemViewerAndEditor().getActions()}

def getConfigPages():
    """
    The config page 
    """
    return {"yeahdocPage":[QApplication.translate("YeahdocPage","title"),\
            getPath("iconDir","yeahdoc/list.png"),"plugins.yeahdoc.yeahdocPage",None],}

class AdapterYeahdocItemViewerAndEditor(QTabWidget,Ui_YeahdocEditor,PluginBase):
    """
    When double click the yeahdoc list item , This will be shown 
    The basic layout has two tabs .
    One is used to show the yeahdoc in HTML
    Another one is used to edit it :)
    in order to make the interface more flexible, we are introducing a html editor.
    Of course, other elements such as tag or classification of these things,
    adjustments in the interface too.
    """
    __Y_MARK_SUBFIX = "~[__yeahdoc__]"
    
    __actions = {}
    
    def getActions(self):
        """
        This method is used by all the action can be configured and returns.
        """
        self.invoke()
        return self.__actions
    
    def __init__(self,id =":new[yeahdoc]"):
        """
        Note that the url spelling.
        In order to ensure that it is only on the main interface,
        we use the id of each yeahdoc to spell out the string.
        Any action against in this instance will affect here.
        """
        
        QTabWidget.__init__(self)
        PluginBase.__init__(self)
        
        self.setKeepme(id+self.__Y_MARK_SUBFIX)
        
    #Override#
    def invoke(self):
              
        self.setupUi(self)

        #our wysiwys editor 
        self.__htmlWYSIWYG = HtmlWYSIWYG(self)
        self.__htmlBrowser=HtmlBrowser(self)

        self.tabeditor.layout().addWidget(self.__htmlWYSIWYG)
        self.tabview.layout().insertWidget(0,self.__htmlBrowser)

        self.passwordMore.setIcon(QIcon(getPath("iconDir","yeahdoc/lock.png")))
        self.passwordWidget.setVisible(False)

        self.__initData()
        self.__initAction()

    
    def __evt_view_change(self,index):
        """
        The function of review event
        """
        {
            0:lambda:self.__loadViewContentFromEditor(),
            1:lambda:True
        }[index]() 
   
    def __loadViewContentFromEditor(self):
        """
        The handle of the review event
        """
        self.__htmlBrowser.setHtml(\
                self.__htmlWYSIWYG.accessPoint().mainFrame().toHtml())
        
        self.titlelabel.setText("<img src='%s'/><span style='color:green;font-weight:bold;font-size:20px'>%s</span>"%(getPath("iconDir","yeahdoc/flag/"+self.flagBtn.text()),self.titleInput.text()))
    
    
    def __initData(self):
        """
        If the `url` is supplied , I will read datas from db and render it 
        otherwise , I just show a empty entry . and noramlly ,setHtml->"" to make it editable
        """
        
        #setup The classlist
        for item in YeahdocDatasSupply().bc_list():
            self.classlist.addItem(item['title'],item['id'])

        #the flag menu 
        self.flagBtn = RichFlagButton(self)
        self.linelayout.insertWidget(0,self.flagBtn)
        
        #if not new .
        if self.keepme() and not self.keepme().startswith(":"):

            yeahdoc = YeahdocDatasSupply().bb_read1(self.keepme().split("~")[0])
            
            content = yeahdoc['content']
            
            if yeahdoc["lock"]==1:
                password,ok = QInputDialog(self).getText(self, "", "",QLineEdit.Password, "")
                if ok:
                    try:
                        content = sk_decode(content,password)
                        self.password1.setText(password)
                        self.password2.setText(password)
                        
                    except:
                        QMessageBox.warning(Seeking.new(), "error", "Error password")
                        raise Exception
                else:
                    raise Exception
            else:
                self.password1.setText("")
                self.password2.setText("")
                    
            
            self.flagBtn.setIcon(QIcon(getPath("iconDir","yeahdoc/flag/%s"%yeahdoc['img'])))
            self.flagBtn.setText(yeahdoc['img'])
            
            self.titleInput.setText(yeahdoc['title'])
            self.__htmlWYSIWYG.accessPoint().mainFrame().setHtml(content)
            self.__htmlBrowser.setHtml(content)

            self.titlelabel.setText("<img src='%s'/><span style='color:green;font-weight:bold;font-size:20px'>%s</span>" %(getPath("iconDir","yeahdoc/flag/%s"%yeahdoc['img']),yeahdoc['title']))

            #flag restore
            for i in range(self.classlist.count()):
                if self.classlist.itemData(i) == yeahdoc['categoryid']:
                    self.classlist.setCurrentIndex(i)
                    break

            self.setCurrentIndex(0)
        else:

            self.titleInput.setText("")
            self.__htmlWYSIWYG.accessPoint().mainFrame().setHtml("")
            self.__htmlBrowser.setHtml("")
            # if the yeahdoc is a new one , then i set it to editor tab
            self.setCurrentIndex(1)

    

    def __initAction(self):
        """
        set up the default action
        """
        
        self.__actions["__yeahdoc_save__"] = QAction(QApplication.translate("YeahdocEditor","Save"),self,\
                                                triggered=self.save)
        self.__actions["__yeahdoc_preview__"] = QAction(QApplication.translate("YeahdocEditor","Preview"),self,\
                                                triggered=lambda :self.setCurrentIndex(0) )
        
        self.__actions["__yeahdoc_save__"].setShortcut(Prefs.new().getShortcut("__yeahdoc_save__","Ctrl+S"))
        self.__actions["__yeahdoc_preview__"].setShortcut(Prefs.new().getShortcut("__yeahdoc_preview__","Ctrl+E"))

        for key in self.__actions.keys():
            self.__actions[key].setIconVisibleInMenu(True)
            self.addAction(self.__actions[key])
        
        #save 
        self.saveBtn.clicked.connect(self.save)
        #password
        self.passwordMore.clicked.connect(lambda:self.passwordWidget.setVisible(not self.passwordWidget.isVisible()))
        #preview 
        QObject.connect(self,SIGNAL("currentChanged (int)"),self.__evt_view_change)

        #change buffer 
        QObject.connect(self.__htmlWYSIWYG.accessPoint(), \
                SIGNAL("contentsChanged ()"),self.onbuffer)
        QObject.connect(self.flagBtn,    SIGNAL("onbuffer ()"),self.onbuffer)
        QObject.connect(self.titleInput, SIGNAL("textChanged (const QString&)"),self.onbuffer)
        QObject.connect(self.password1,  SIGNAL("textChanged (const QString&)"),self.onbuffer)
        QObject.connect(self.password2,  SIGNAL("textChanged (const QString&)"),self.onbuffer)
        QObject.connect(self.tagsInput,  SIGNAL("textChanged (const QString&)"),self.onbuffer)
        
        
    
    def save(self):
        """
        Handle save event . Before saved , checked if has password set . 
        The password is encrypt with pyDes
        """
        if self.bufferon():
            #get the password
            password = ""
            password1=self.password1.text()
            password2=self.password2.text()
            
            if not  password1 == "" or not password2 == "":
                if password1==password2:
                    password = password1
                else:
                    QMessageBox.warning(Seeking.new(), "error", "Not match")
                    return
            
            #loading effert
            Seeking.new().overlay.show()

            #if it's a new yeahdoc item instance
            if self.keepme() is  "" or  self.keepme().startswith(":"):
                id = "~"
            #notice we contact the str at __init__ method
            else:
                id = self.keepme().split('~')[0]
                
            #Values 
            title   = self.titleInput.text()
            content = self.__htmlWYSIWYG.accessPoint().mainFrame().toHtml()
                
            img     = self.flagBtn.text()
            tags    = self.tagsInput.text()
            categoryid = self.classlist.itemData(self.classlist.currentIndex())
            
            #Just save will change it , update opreation will just repeat it 
            self.setKeepme(
                    YeahdocDatasSupply().bb_save(categoryid.toString(),title,tags,img,content,password,id)+\
                    self.__Y_MARK_SUBFIX)
            
            #in order to make the suitable width of tab.
            title = "%s.."%title[0:8] if len(title)>8 else title
            index = Seeking.new().tabs.indexOf(self)

            Seeking.new().tabs.setTabIcon(index,QIcon(getPath("iconDir","yeahdoc/flag/%s"%img)))
            Seeking.new().tabs.setTabText(index,title)

            self.setBufferon(False)
            
            Seeking().new().overlay.hidestop()
        else:
            pass

class RichFlagButton(QPushButton):
    """
    This will send an event self.emit(SIGNAL("onbuffer()"))
    """
    def __init__(self,parent=None):
        QPushButton.__init__(self,parent)
        self.setMenu(self.__richflag())
        #flag
        self.setIcon(QIcon(getPath("iconDir","yeahdoc/flag/default.png")))
        self.setText("default.png")
        
    def __richflag(self):
        """
        Show many many colorfull icon to make the yeahdoc flag . 
        """
        menu = QMenu(self)
        
        for item in os.listdir(getPath("iconDir","yeahdoc/flag")):
            if item.endswith("png"):
                action = QAction(QIcon(getPath("iconDir","yeahdoc/flag/%s"%item)),item,self,\
                        triggered=lambda re,item=item:self.__evt_richflag_menu_click(item))
                action.setIconVisibleInMenu(True)
                menu.addAction(action)
        return menu
        
    @pyqtSignature("")
    def __evt_richflag_menu_click(self,item):
        """
        IF ICON CHANGED , save flag will be active .
        """
        self.setIcon(QIcon(getPath("iconDir","yeahdoc/flag/%s"%item)))
        self.setText(item)
        self.emit(SIGNAL("onbuffer()"))
        
class AdapterMainYeahdocListView(Ui_YeahdocList,QWidget,PluginBase): 
    """
    This will be added to mainlayout as tab!
    We have both the class list and yeahdoclist in the same viewer
    """
    
    __actions = {}
    
    def getActions(self):
        self.invoke()
        return  self.__actions
    
    class __NewBCWidget(QDialog,Ui_NewYeahdocCategory):
        """
        This is a inner class used to add a new yeahdoc class.
        This will show a widget that recive inputs 
        And will make effect to its parent 
        """
        def __init__(self,parent=None,id="~"):
            """
            init
            """
            QWidget.__init__(self,parent)
            self.setupUi(self)

            #center this window 
            screen = QDesktopWidget().screenGeometry()
            size = self.geometry()
            self.move((screen.width()-size.width())/2, (screen.height()-size.height())/2)
                        
            self.id = id
            self.flagBtn = RichFlagButton(self)
            self.linelayout.addWidget(self.flagBtn)
            self.desc = HtmlWYSIWYG()
            self.desc.setMinimumHeight(200)
            self.desclayout.addWidget(self.desc)
            
            if not self.id == "~":
                restore = YeahdocDatasSupply().bc_read1(self.id)
                self.flagBtn.setIcon(QIcon(getPath("iconDir","yeahdoc/flag/%s"%str(restore['img']))))
                self.flagBtn.setText(restore['img'])
                self.title.setText(restore['title'])
                self.desc.accessPoint().mainFrame().setHtml(restore['desc'])
                
            QObject.connect(self.btn, SIGNAL("clicked (QAbstractButton *)"),self.__evt_btn_click)
            
        def __evt_btn_click(self,btn):
            """
            save or cancel
            """
            if btn == self.btn.button(QDialogButtonBox.Ok):
                self.save()
            elif btn == self.btn.button(QDialogButtonBox.Cancel):
                self.close()
                
        def save(self):
            """
            save the yeahdoc 
            """
            title   = self.title.text()
            desc    = self.desc.accessPoint().mainFrame().toHtml()
            img     = self.flagBtn.text()
            
            if title == None or title == "" or desc == None or desc == "":
                QMessageBox.warning(self, "Warn", "title and desc can not be null")
                return
    
            YeahdocDatasSupply().bc_save(title, img, desc, self.id)
            
            self.parent().refreshClasslist()
            self.close()
            
    class __YeahdocQTreeWidgetItem(QTreeWidgetItem):
        """
        used to record extend data
        every tree item will use this
        """
        def __init__(self):
            QTreeWidgetItem.__init__(self)
            #used to record the yeahdoc item
            self.__mark = None
        def getMark(self):
            return self.__mark
        def setMark(self,mark):
            self.__mark = mark
            
    class __YeahdocCategoryQListWidgetItem(QListWidgetItem):
        """
        the yeahdoc class list item 
        """
        def __init__(self):
            QListWidgetItem.__init__(self)
            #used to record the yeahdoc item
            self.__mark = None
        def getMark(self):
            return self.__mark
        def setMark(self,mark):
            self.__mark = mark
            
    def __init__(self,parent=None):
        """
        Just init ... supply a url mark sure
        """
        QWidget.__init__(self,parent)
        PluginBase.__init__(self)
        #just mark it is the single one
        self.setKeepme("(__yeahdoc_list__)")
        
    #Override
    def invoke(self):
        """
        the real setup function to show someting.
        """
        self.setupUi(self)
        
        #make sure the first col show full
        self.yeahdoclisttree.header().setResizeMode(0,QHeaderView.ResizeToContents)
        
        
        self.__initAction()
        
        #toolbar .
        classToolbar = QToolBar()
        classToolbar.setIconSize(QSize(16,16))
        classToolbar.setMovable(False)
        self.rightsplitter.insertWidget(0,classToolbar)
        
        
        classToolbar.addAction(self.__actions["__yeahdoc_c_new__"])
        classToolbar.addAction(self.__actions["__yeahdoc_c_edit__"])
        classToolbar.addAction(self.__actions["__yeahdoc_c_rename__"])
        classToolbar.addAction(self.__actions["__yeahdoc_c_delete__"])
        classToolbar.addWidget(self.__evt_category_view())
        
        #More useful gadgets
        self.togglebtn.setIcon(QIcon(getPath("iconDir","yeahdoc/right.png")))
        self.__initMoreGadgets()
        
        
        #read datas from db .
        self.__setupYeahdocCategoryDatas()
        self.__setupyeahdoclisttreeDatas()
        
    #Override  
    def after(self):
        #tour
        if self.yeahdoclisttree.topLevelItemCount() <=0 :
            QMessageBox.information(self, "Info", "Current No items now . You may want import some datas")
            self.moreBtn.showMenu()

    def __initMoreGadgets(self):
        self.moreBtn.setIcon(QIcon(getPath("iconDir","yeahdoc/more.png")))
        moreMenu = QMenu(self.moreBtn)
        
        qwa = QWidgetAction(moreMenu)
        qwa.setDefaultWidget(QLabel("<span style='font-weight:bold;font-size:14px;color:red'>%s</span>"%QApplication.translate("YeahdocList","Import...")))
        moreMenu.addAction(qwa)
        moreMenu.addSeparator()
        
        action = QAction(QIcon(getPath("iconDir","yeahdoc/ext/wordpress.png")),QApplication.translate("YeahdocList","TODO:Import datas from Wordpress.."),self)
        action.setIconVisibleInMenu(True)
        moreMenu.addAction(action)
        
        action = QAction(QIcon(getPath("iconDir","yeahdoc/ext/qq.png")),QApplication.translate("YeahdocList","Import your Qzone datas.."),self,triggered=lambda :ImExportTools().importQZone())
        action.setIconVisibleInMenu(True)
        moreMenu.addAction(action)
        
        action = QAction(QIcon(getPath("iconDir","yeahdoc/ext/douban.png")),QApplication.translate("YeahdocList","TODO:Import datas from douban.."),self)
        action.setIconVisibleInMenu(True)
        moreMenu.addAction(action)
        
        action = QAction(QIcon(getPath("iconDir","yeahdoc/ext/javaeye.png")),QApplication.translate("YeahdocList","TODO:Import datas from Javaeye.."),self)
        action.setIconVisibleInMenu(True)
        moreMenu.addAction(action)
        
        action = QAction(QIcon(getPath("iconDir","yeahdoc/ext/csdn.png")),QApplication.translate("YeahdocList","TODO:Import datas from CSDN.."),self)
        action.setIconVisibleInMenu(True)
        moreMenu.addAction(action)
        
        action = QAction(QIcon(getPath("iconDir","yeahdoc/ext/baidu.png")),QApplication.translate("YeahdocList","TODO:Import datas from baidu-hi.."),self)
        action.setIconVisibleInMenu(True)
        moreMenu.addAction(action)
        
        qwa = QWidgetAction(moreMenu)
        qwa.setDefaultWidget(QLabel("<span style='font-weight:bold;font-size:14px;color:blue'>%s</span>"%QApplication.translate("YeahdocList","Export...")))
        moreMenu.addAction(qwa)
        moreMenu.addSeparator()
        
        action = QAction(QIcon(getPath("iconDir","yeahdoc/ext/wordpress.png")),QApplication.translate("YeahdocList","TODO:Export to Wordpress.."),self)
        action.setIconVisibleInMenu(True)
        moreMenu.addAction(action)
        
        action = QAction(QIcon(getPath("iconDir","yeahdoc/ext/rss.png")),QApplication.translate("YeahdocList","TODO:Export as rss.."),self)
        action.setIconVisibleInMenu(True)
        moreMenu.addAction(action)
        
        action = QAction(QIcon(getPath("iconDir","yeahdoc/ext/html.png")),QApplication.translate("YeahdocList","TODO:Export as html.."),self)
        action.setIconVisibleInMenu(True)
        moreMenu.addAction(action)
        
        
        
        self.moreBtn.setMenu(moreMenu)
    def __initAction(self): 
        """
        action that handle the event
        """
        #open
        self.__actions["__yeahdoc_open__"] = \
                QAction(QIcon(getPath("iconDir","yeahdoc/open.png")),QApplication.translate("YeahdocList","Open"),self,\
                         triggered=self.__evt_yeahdoc_Xopen0)
        #edit 
        self.__actions["__yeahdoc_edit__"] = \
                QAction(QIcon(getPath("iconDir","yeahdoc/edit.png")),QApplication.translate("YeahdocList","Edit"),self,\
                         triggered=lambda :self.__evt_yeahdoc_Xopen0(True))
        #star
        self.__actions["__yeahdoc_star__"] = \
                QAction(QIcon(getPath("iconDir","yeahdoc/star.png")),QApplication.translate("YeahdocList","Toggle Star"),self,\
                         triggered=self.__evt_yeahdoc_star)
        #rename
        self.__actions["__yeahdoc_rename__"] = \
                QAction(QIcon(getPath("iconDir","yeahdoc/rename.png")),QApplication.translate("YeahdocList","Rename"),self,\
                         triggered=self.__evt_yeahdoc_rename)
        #delete
        self.__actions["__yeahdoc_delete__"] = \
                QAction(QIcon(getPath("iconDir","yeahdoc/delete.png")),QApplication.translate("YeahdocList","Delete"), self,\
                        triggered=self.__evt_yeahdoc_delete_item)
        #new
        self.__actions["__yeahdoc_c_new__"] = \
                QAction(QIcon(getPath("iconDir","yeahdoc/categorynew.png")),QApplication.translate("YeahdocList","new category"),self,\
                        triggered=self.__evt_category_new)
        #edit
        self.__actions["__yeahdoc_c_edit__"] = \
                QAction(QIcon(getPath("iconDir","yeahdoc/categoryedit.png")),QApplication.translate("YeahdocList","Edit"),self,\
                        triggered=self.__evt_category_edit)
        #rename
        self.__actions["__yeahdoc_c_rename__"] = \
                QAction(QIcon(getPath("iconDir","yeahdoc/rename.png")),QApplication.translate("YeahdocList","Rename"),self,\
                        triggered=self.__evt_category_rename)
        #delete
        self.__actions["__yeahdoc_c_delete__"] = \
                QAction(QIcon(getPath("iconDir","yeahdoc/categorydelete.png")),QApplication.translate("YeahdocList","Delete"),self,\
                        triggered=self.__evt_category_delete)
        #clear datas 
        self.__actions["__yeahdoc_c_cleardatas__"] = \
                QAction(QIcon(getPath("iconDir","yeahdoc/cleardatas.png")),QApplication.translate("YeahdocList","Clear"),self,\
                        triggered=self.__evt_category_cleardatas)
        

        self.__actions["__yeahdoc_open__"].setShortcut(Prefs.new().getShortcut("__yeahdoc_open__","Ctrl+O"))
        self.__actions["__yeahdoc_edit__"].setShortcut(Prefs.new().getShortcut("__yeahdoc_edit__","Ctrl+E"))
        self.__actions["__yeahdoc_star__"].setShortcut(Prefs.new().getShortcut("__yeahdoc_star__","Alt+M"))
        self.__actions["__yeahdoc_rename__"].setShortcut(Prefs.new().getShortcut("__yeahdoc_rename__","F2"))
        self.__actions["__yeahdoc_delete__"].setShortcut(Prefs.new().getShortcut("__yeahdoc_delete__","Delete"))
        
        self.__actions["__yeahdoc_c_new__"].setShortcut(Prefs.new().getShortcut("__yeahdoc_c_new__",""))
        self.__actions["__yeahdoc_c_edit__"].setShortcut(Prefs.new().getShortcut("__yeahdoc_c_edit__",""))
        self.__actions["__yeahdoc_c_rename__"].setShortcut(Prefs.new().getShortcut("__yeahdoc_c_rename__",""))
        self.__actions["__yeahdoc_c_delete__"].setShortcut(Prefs.new().getShortcut("__yeahdoc_c_delete__",""))
        
        for key in self.__actions.keys():
            self.__actions[key].setIconVisibleInMenu(True)
            self.addAction(self.__actions[key])
            
        #toggle buttion
        QObject.connect(self.togglebtn,\
                        SIGNAL("clicked ()"),\
                        self.__evt_toggle_view)

        #double click the yeahdoc tree list,open a new window at main tab 
        QObject.connect(self.yeahdoclisttree, \
                SIGNAL("itemDoubleClicked (QTreeWidgetItem *,int)"),\
                self.__evt_yeahdoc_Xopen)

        QObject.connect(self.yeahdoclisttree, \
                SIGNAL("itemChanged (QTreeWidgetItem *,int)"),\
                self.__evt_yeahdoc_rename_done)

        QObject.connect(self.yeahdoclisttree, \
                SIGNAL("currentItemChanged (QTreeWidgetItem *,QTreeWidgetItem *)"),\
                self.__evt_yeahdoc_currentItemChanged)

        QObject.connect(self.yeahdoccategorylist, \
                SIGNAL("itemChanged (QListWidgetItem *)"),\
                self.__evt_category_rename_done)
        
        QObject.connect(self.yeahdoccategorylist, \
                SIGNAL("currentItemChanged (QListWidgetItem *,QListWidgetItem *)"),\
                self.__evt_category_currentItemChanged)
        #right click the yeahdoc tree list and show a context menu
        QObject.connect(self.yeahdoclisttree, \
                SIGNAL("customContextMenuRequested (const QPoint&)"),\
                self.__evt_yeahdoc_contextMenu)

        QObject.connect(self.yeahdoccategorylist, \
                SIGNAL("customContextMenuRequested (const QPoint&)"),\
                self.__evt_category_contextMenu)
        #double click the yeahdoc class list
        QObject.connect(self.yeahdoccategorylist,\
                SIGNAL("itemDoubleClicked (QListWidgetItem *)"),\
                self.__evt_category_dbclick)
        
        QObject.connect(self.searchEdit,SIGNAL("textChanged (const QString&)"),self.__search)
    def __search(self,txt):
        """
        search match
        """
        for topIndex in range(self.yeahdoclisttree.topLevelItemCount()):
            topItem = self.yeahdoclisttree.topLevelItem(topIndex)
            
            if  not topItem.text(0).__contains__(txt):
                topItem.setHidden(True)
            else:
                topItem.setHidden(False)
           
    def refreshClasslist(self):
        """
        call me outside
        """
        self.__setupYeahdocCategoryDatas()
        
    def __setupYeahdocCategoryDatas(self):
        """
        Read class list .
        """
        self.yeahdoccategorylist.clear()
        #read
        yeahdoccategorylist = YeahdocDatasSupply().bc_list()
        for item in yeahdoccategorylist:
                    
            newItem = self.__YeahdocCategoryQListWidgetItem()
            newItem.setMark(str(item["id"]))
            newItem.setText(item['title'])
            newItem.setIcon(QIcon(getPath("iconDir","yeahdoc/flag/%s"%str(item["img"]))))
            self.yeahdoccategorylist.addItem(newItem)
            

    def __setupyeahdoclisttreeDatas(self,categoryid=None):
        """
        Set up the yeahdoc's datas 
        By default 
        """
        #clear first
        self.yeahdoclisttree.clear()   
        #read datas
        for item in YeahdocDatasSupply().bb_list(categoryid):
            treeitem = self.__YeahdocQTreeWidgetItem()
            
            treeitem.setText(0,item["title"])
            treeitem.setIcon(0,QIcon(getPath("iconDir","yeahdoc/flag/%s"%item["img"])))
            
            treeitem.setText(1,item["createdate"])
            
            treeitem.setMark(str(item['id']))
            
            if 1==item['star']:treeitem.setIcon(2,QIcon(getPath("iconDir","yeahdoc/star.png")))
            if 1==item['lock']:treeitem.setIcon(3,QIcon(getPath("iconDir","yeahdoc/lock.png")))
            
            self.yeahdoclisttree.addTopLevelItem(treeitem)

    def __evt_toggle_view(self):
        """
        show or hide the right part
        """
        if self.rightpart.isVisible():
            self.rightpart.setVisible(False)
            self.togglebtn.setIcon(QIcon(getPath("iconDir","yeahdoc/left.png")))
        else:
            self.rightpart.setVisible(True)    
            self.togglebtn.setIcon(QIcon(getPath("iconDir","yeahdoc/right.png")))
        
        
    def __evt_category_view(self):
        """
        view by 
        """
        btn = QToolButton()
        btn.setIcon(QIcon(getPath("iconDir","yeahdoc/view.png")))
        
        menu = QMenu(btn)
        menu.addAction(QAction("ListMode",self,\
                        triggered=lambda :self.yeahdoccategorylist.setViewMode(QListView.ListMode)))
        menu.addAction(QAction("IconMode",self,\
                        triggered=lambda :self.yeahdoccategorylist.setViewMode(QListView.IconMode)))
        
        btn.setMenu(menu)
        
        return btn
      
    def __evt_category_contextMenu(self,p):
        """
        yeahdoc class context menu
        """
        item = self.yeahdoccategorylist.currentItem()
        
        if item and item.getMark():
            
            menu = QMenu()
            
            action = QAction(QIcon(getPath("iconDir","yeahdoc/item.png")),item.text(),self)
            action.setIconVisibleInMenu(True)
            menu.addAction(action)
            
            menu.addSeparator()
            
            action = QAction(QIcon(getPath("iconDir","yeahdoc/open.png")),QApplication.translate("YeahdocList","Open"),self,\
                             triggered=lambda re,id=item.getMark():self.__setupyeahdoclisttreeDatas(id))
            action.setIconVisibleInMenu(True)
            menu.addAction(action)

            action = QAction(QIcon(getPath("iconDir","yeahdoc/refresh.png")),QApplication.translate("YeahdocList","Refresh"),self,\
                             triggered=self.refreshClasslist)
            action.setIconVisibleInMenu(True)
            menu.addAction(action)
            
            menu.addSeparator()
            
            #merge class
            merge_class_menu = QMenu()
            current_categoryid = item.getMark()
            for class_item in YeahdocDatasSupply().bc_list():
                if not str(class_item['id'])== current_categoryid:
                    action = QAction(class_item["title"],self,\
                                        triggered=lambda re,item=item,categoryid=str(class_item["id"]):\
                                        YeahdocDatasSupply().bc_merge(current_categoryid,categoryid))
                    action.setIcon(QIcon(getPath("iconDir","yeahdoc/flag/%s"%str(class_item["img"]))))
                    action.setIconVisibleInMenu(True)
                    merge_class_menu.addAction(action)
            
            action = QAction(QIcon(getPath("iconDir","yeahdoc/merge.png")),QApplication.translate("YeahdocList","Merge"),self)
            action.setIconVisibleInMenu(True)
            action.setMenu(merge_class_menu)
            menu.addAction(action)
            menu.addAction(self.__actions["__yeahdoc_c_cleardatas__"])
            menu.addSeparator()

            menu.addAction(self.__actions["__yeahdoc_c_new__"])
            menu.addAction(self.__actions["__yeahdoc_c_edit__"])
            menu.addAction(self.__actions["__yeahdoc_c_rename__"])
            menu.addAction(self.__actions["__yeahdoc_c_delete__"])

            menu.exec_(self.mapToGlobal(self.yeahdoccategorylist.mapTo(self,p)))
        
    def __evt_yeahdoc_contextMenu(self,p):
        """
        context menu
        """
        item = self.yeahdoclisttree.currentItem()
        if item == None or item.isDisabled():
            pass
        else:
            menu = QMenu()
            
            #menu top 
            action = QWidgetAction(self)
            action.setDefaultWidget(QLabel("&nbsp;&nbsp;<img  src='%s'/>  &nbsp;%s"% (getPath("iconDir","yeahdoc/item.png"),item.text(0))))
            menu.addAction(action)
            
            menu.addSeparator()
            
            menu.addAction(self.__actions["__yeahdoc_open__"])
            menu.addAction(self.__actions["__yeahdoc_edit__"])
            
            #change class
            change_class_menu = QMenu()
            entry = YeahdocDatasSupply().bb_read1_simple(item.getMark())
            current_categoryid = entry['categoryid']
            for class_item in YeahdocDatasSupply().bc_list():
                action = QAction(class_item["title"],self,\
                                    triggered=lambda re,item=item,categoryid=str(class_item["id"]):\
                                    self.__evt_change_category(categoryid,item))
                action.setIcon(QIcon(getPath("iconDir","yeahdoc/flag/%s"%str(class_item["img"]))))
                action.setIconVisibleInMenu(True)
                #mark current class id menu checked 
                if class_item['id']==current_categoryid:
                    action.setCheckable(True)
                    action.setChecked(True)
                    action.setDisabled(True)
                change_class_menu.addAction(action)
                
            action = QAction(QIcon(getPath("iconDir","yeahdoc/change.png")),QApplication.translate("YeahdocList","Change Category"),self)
            action.setIconVisibleInMenu(True)
            action.setMenu(change_class_menu)
            
            menu.addAction(action)
            
            
            menu.addAction(self.__actions["__yeahdoc_star__"])
            menu.addAction(self.__actions["__yeahdoc_rename__"])
            menu.addAction(self.__actions["__yeahdoc_delete__"])
            
            menu.addSeparator()
            
            setmode = True if entry['lock']==0 else False
            action = QWidgetAction(self)
            widget = QWidget()
            layout = QHBoxLayout()
            layout.setSpacing(0)
            layout.setMargin(0)
            widget.setLayout(layout)
            widgetMore = QWidget()
            widgetMore.setVisible(False)
            layoutMore = QHBoxLayout()
            layoutMore.setSpacing(0)
            layoutMore.setMargin(0)
            widgetMore.setLayout(layoutMore)
            
            layout.addWidget(QLabel("<img src='%s'/>"%getPath("iconDir","yeahdoc/password.png")))
            passwordMore = QPushButton(QApplication.translate("YeahdocEditor","Encrypt") if setmode else QApplication.translate("YeahdocEditor","Decrypt"))
            passwordMore.setFlat(True)
            layout.addWidget(passwordMore)
            
            passwordInput = QLineEdit()
            passwordInput.setEchoMode(QLineEdit.Password)
            passwordInput.setMaximumWidth(70)
            
            layoutMore.addWidget(passwordInput)
            
            if setmode:
                passwordInputAgain = QLineEdit()
                passwordInputAgain.setEchoMode(QLineEdit.Password)
                passwordInputAgain.setMaximumWidth(70)
                layoutMore.addWidget(QLabel(QApplication.translate("YeahdocEditor","Re")))
                layoutMore.addWidget(passwordInputAgain)
            
            passwordSubmit = QPushButton("OK")
            passwordSubmit.setFlat(True)
            layoutMore.addWidget(passwordSubmit)
            
            layout.addWidget(widgetMore)
            layout.addItem(QSpacerItem(0, 20, QSizePolicy.Expanding, QSizePolicy.Expanding))
            
            
            action.setDefaultWidget(widget)
            QObject.connect(passwordSubmit, SIGNAL("clicked ()"),lambda:self.__evt_password(setmode,passwordInput.text(),passwordInputAgain.text() if setmode else ""))
            QObject.connect(passwordMore, SIGNAL("clicked ()"),lambda:widgetMore.setVisible(not widgetMore.isVisible()))
            
            menu.addAction(action)
            
            #show it.
            menu.exec_(self.mapToGlobal(self.yeahdoclisttree.mapTo(self,p)))
    def __evt_change_category(self,categoryid,item):
        """
        change the category of the item
        """
        YeahdocDatasSupply().bb_update_class(categoryid,item.getMark())
        item.setHidden(True)

    def __evt_password(self,setmode,password,repassword):
        """
        set the password of the item.
        """
        item = self.yeahdoclisttree.currentItem()
        if item and password:
            try:
                d = YeahdocDatasSupply().bb_read1(item.getMark())["content"]
                if setmode:
                    if password==repassword:
                        YeahdocDatasSupply().bb_lock(item.getMark(),password)
                        QMessageBox.information(Seeking.new(), "Success", "%s Success"%QApplication.translate("YeahdocEditor","Encrypt"))
                        item.setIcon(3,QIcon(getPath("iconDir","yeahdoc/lock.png")))
                    else:
                        QMessageBox.warning(Seeking.new(), "error", "Not match")
                else:
                    YeahdocDatasSupply().bb_unlock(item.getMark(),password)
                    QMessageBox.information(Seeking.new(), "Success", "%s Success"%QApplication.translate("YeahdocEditor","Decrypt"))
                    item.setIcon(3,QIcon(None))
            except:
                QMessageBox.warning(Seeking.new(), "error", "Error password")
    def __evt_category_rename(self):
        """
        rename
        """
        item = self.yeahdoccategorylist.currentItem()
        if item :
            self.yeahdoccategorylist.openPersistentEditor(item)
            self.yeahdoccategorylist.editItem(item)
        
    def __evt_category_cleardatas(self):
        """
        clear the datas contains in this category
        """
        item = self.yeahdoccategorylist.currentItem()
        if item :
            reply = QMessageBox.question(self, "Clear Data?",
                    "Really Clear ? \n %s"%item.text(),QMessageBox.Yes | QMessageBox.No )
            if reply == QMessageBox.Yes:
                YeahdocDatasSupply().bc_clear(item.getMark())
            elif reply == QMessageBox.No:
                pass
            else:
                pass

    def __evt_category_delete(self):
        """
        delete current item
        """
        item = self.yeahdoccategorylist.currentItem()
        if item :
            reply = QMessageBox.question(self, "Delete!",
                    "Really Delete? %s"%item.text(),QMessageBox.Yes | QMessageBox.No )
            if reply == QMessageBox.Yes:
                if YeahdocDatasSupply().bc_delete(item.getMark()):
                    self.refreshClasslist()
            elif reply == QMessageBox.No:
                pass
            else:
                pass
        
    def __evt_category_rename_done(self,item):
        """
        do rename
        """
        YeahdocDatasSupply().bc_update_title(item.text(),str(item.getMark()))
        self.yeahdoccategorylist.openPersistentEditor(item)

    def __evt_category_new(self):
        """
        just append a yeahdoc class item
        """
        newclass = self.__NewBCWidget(self)
        newclass.show()
        
    def __evt_category_edit(self):
        """
        edit yeahdoc class item
        """
        item = self.yeahdoccategorylist.currentItem()
        if item :
            newclass = self.__NewBCWidget(self,item.getMark())
            newclass.show()
        
    def __evt_category_currentItemChanged(self,item1,item2):
        """
        just set the rename state off
        """
        self.yeahdoccategorylist.closePersistentEditor(item1)
        self.yeahdoccategorylist.closePersistentEditor(item2)
        if item1 and item1.getMark() :
            self.preview.setHtml(YeahdocDatasSupply().bc_read1(item1.getMark())["desc"])
        
    def __evt_yeahdoc_currentItemChanged(self,item1,item2):
        """
        just set the rename state off
        """
        self.yeahdoclisttree.closePersistentEditor(item1)
        self.yeahdoclisttree.closePersistentEditor(item2)
        
        if item1 and item1.getMark() :
            self.preview.setHtml(YeahdocDatasSupply().bb_read1_simple(item1.getMark())["desc"])

    def __evt_category_dbclick(self,item):
        """
        setup treelist by class id
        """
        self.__setupyeahdoclisttreeDatas(item.getMark())
    def __evt_yeahdoc_Xopen0(self,edit=False):
        """
        defaut
        """
        self.__evt_yeahdoc_Xopen(self.yeahdoclisttree.currentItem(),0,edit)
    def __evt_yeahdoc_Xopen(self,item,index,edit=False):
        """
        real open the item . if edit=True . then switch it to edit tab default
        """
        if item == None or item.isDisabled():
            pass
        else:
            id = item.getMark()
            simple_info = YeahdocDatasSupply().bb_read1_simple(id)
            editor=AdapterYeahdocItemViewerAndEditor(id)
            editor.execute(simple_info['title'],\
                    QIcon(getPath("iconDir","yeahdoc/flag/%s"%simple_info['img'])))
            if edit:
                editor.setCurrentIndex(1)
    def __evt_yeahdoc_star(self):
        """
        star it 
        TODO:
        """
        item = self.yeahdoclisttree.currentItem()
        if 0==YeahdocDatasSupply().bb_toggle_star(item.getMark()):
            item.setIcon(2,QIcon(getPath("iconDir","yeahdoc/star.png")))
        else:
            item.setIcon(2,QIcon(None))
            
    def __evt_yeahdoc_rename(self):
        """
        rename evt
        """
        item = self.yeahdoclisttree.currentItem()
        self.yeahdoclisttree.openPersistentEditor(item,0)
        self.yeahdoclisttree.editItem(item,0)
        
    def __evt_yeahdoc_rename_done(self,item,index):
        """
        do rename
        """
        YeahdocDatasSupply().bb_update_title(item.text(0), item.getMark())
        self.yeahdoclisttree.closePersistentEditor(item)
    #Delete it from db , and more , make it disabled 
    def __evt_yeahdoc_delete_item(self):
        """
        delete item
        """
        item = self.yeahdoclisttree.currentItem()
        reply = QMessageBox.question(self, "Delete!",
                    "Really Delete? \n %s"%item.text(0),QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            if YeahdocDatasSupply().bb_delete(item.getMark()):
                item.setDisabled(True)
                item.setHidden(True)
        elif reply == QMessageBox.No:
            pass
        else:
            pass
    
